# LibraryManagementSystem
creating a basic skeleton api  structure for the library management system  using django
